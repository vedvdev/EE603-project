static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#c5c8c6", "#1d1f21" },
	[SchemeSel] = { "#000000", "#b77ee0" },
	[SchemeSelHighlight] = { "#9ec400", "#000000" },
	[SchemeNormHighlight] = { "#9ec400", "#000000" },
	[SchemeOut] = { "#000000", "#54ced6" },
	[SchemeMid] = { "#c5c8c6", "#000000" },
};
