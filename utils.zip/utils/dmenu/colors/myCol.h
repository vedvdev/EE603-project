
static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#93a1a1", "#002b36" },
	[SchemeSel] = { "#fdf6e3", "#268bd2" },
	[SchemeSelHighlight] = { "#93a1a1", "#002b36" },
	[SchemeNormHighlight] = { "#93a1a1", "#002b36" },
	[SchemeOut] = { "#93a1a1", "#002b36" },
	[SchemeMid] = { "#93a1a1", "#002b36" },
};
