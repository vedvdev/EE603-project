static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#d8dee9", "#1b2b34" },
	[SchemeSel] = { "#000000", "#c594c5" },
	[SchemeSelHighlight] = { "#99C794", "#000000" },
	[SchemeNormHighlight] = { "#99C794", "#000000" },
	[SchemeOut] = { "#ffffff", "#6699cc" },
	[SchemeMid] = { "#d8dee9", "#000000" },
};
