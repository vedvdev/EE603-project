static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#cccccc", "#282c34" },
	[SchemeSel] = { "#1c1f24", "#c678dd" },
	[SchemeSelHighlight] = { "#98be65", "#000000" },
	[SchemeNormHighlight] = { "#98be65", "#000000" },
	[SchemeOut] = { "#000000", "#51afef" },
	[SchemeMid] = { "#d7d7d7", "#1c1f24" },
};
