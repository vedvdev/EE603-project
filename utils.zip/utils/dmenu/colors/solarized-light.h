static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#657b83", "#fdf6e3" },
	[SchemeSel] = { "#ffffff", "#d33682" },
	[SchemeSelHighlight] = { "#2aa198", "#000000" },
	[SchemeNormHighlight] = { "#2aa198", "#000000" },
	[SchemeOut] = { "#ffffff", "#268bd2" },
	[SchemeMid] = { "#073642", "#eee8d5" },
};
