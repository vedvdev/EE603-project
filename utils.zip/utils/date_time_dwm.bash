#! /bin/bash 
while [ True ]; do xsetroot -name "$(date) | Battery: $(cat /sys/class/power_supply/BAT0/capacity)%"; sleep 1; done
